//
// Created by bytedance on 2020/12/8.
//

#ifndef CONFIG_ORDER_BN254_H
#define CONFIG_ORDER_BN254_H

#define MBITS_BN254_N 254
#define MOD8_BN254_N 3
#define MODTYPE_BN254_N NOT_SPECIAL
#define MAXXES_BN254_N 26

#endif //ABE_CONFIG_ORDER_BN254_H
